#!/bin/bash

echo "=================================================="
echo "   Starting Financial Ledger Setup (macOS)        "
echo "=================================================="

# Navigate to backend directory
cd backend

# 1. Check if virtual environment already exists
if [ -d "venv" ]; then
    echo "[1/4] Virtual environment (venv) already exists. Skipping creation."
else
    echo "[1/4] Creating Python virtual environment (venv)..."
    python3 -m venv venv
fi

# 2. Activate virtual environment and apply requirements
echo "[2/4] Activating venv and applying requirements.txt..."
source venv/bin/activate
pip install --upgrade pip > /dev/null 2>&1

if [ -f "requirements.txt" ]; then
    pip install -r requirements.txt
else
    echo "Warning: requirements.txt not found in backend directory!"
fi

# 3. Start Flask Backend in the background and redirect output to logs.txt
echo "[3/4] Starting Python Flask API server (Logs: backend/logs.txt)..."
python3 app.py > logs.txt 2>&1 &
FLASK_PID=$!

# Return to root directory
cd ..

# Wait 3 seconds for the server to spin up
sleep 3

# 4. Open Frontend HTML in default browser
echo "[4/4] Opening Frontend in default browser..."
open frontend/index.html

echo "=================================================="
echo " Setup complete! Backend is running (PID: $FLASK_PID)."
echo " - Active venv: backend/venv"
echo " - Server logs: backend/logs.txt"
echo "=================================================="

# Keep the script alive so background process tracking works smoothly
wait $FLASK_PID