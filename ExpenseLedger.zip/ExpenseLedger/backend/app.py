import os
import openpyxl
from flask import Flask, jsonify, request
from flask_cors import CORS
from datetime import datetime

app = Flask(__name__)
CORS(app)

DESKTOP_PATH = os.path.join(os.path.expanduser("~"), "Desktop")
ACCOUNTS_ROOT = os.path.join(DESKTOP_PATH, "Accounts")


@app.route('/api/save-entry', methods=['POST'])
def save_entry():
    try:
        data = request.json
        scenario = data.get('scenario')
        amount = float(data.get('amount'))
        description = data.get('description', '')
        custom_date = data.get('date') # e.g., "2026-10-15T18:30:00.000Z" or "2026-10-16"

        if custom_date:
            clean_date_str = str(custom_date)[:10]
            entry_date = datetime.strptime(clean_date_str, '%Y-%m-%d')
        else:
            entry_date = datetime.now()

        year_str = entry_date.strftime('%Y')
        month_str = entry_date.strftime('%B') # e.g. October
        date_str = entry_date.strftime('%Y-%m-%d')
        time_str = datetime.now().strftime('%H:%M:%S')

        target_dir = os.path.join(ACCOUNTS_ROOT, year_str, month_str)
        os.makedirs(target_dir, exist_ok=True)

        # Compatible string formatting for all Python versions
        file_path = os.path.join(target_dir, "{}.xlsx".format(date_str))

        if os.path.exists(file_path):
            wb = openpyxl.load_workbook(file_path)
            ws = wb.active
        else:
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = "Ledger"
            ws.append(["Timestamp", "Scenario", "Amount", "Description"])

        ws.append([time_str, scenario, amount, description])
        wb.save(file_path)

        success_msg = "Entry saved successfully for {}!".format(date_str)
        return jsonify({"status": "success", "message": success_msg}), 200

    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"status": "error", "message": str(e)}), 500

def format_nice_date(date_str):
    """Converts 'YYYY-MM-DD' into 'DD-Mon-YYYY' e.g. '12-Sept-2026'"""
    try:
        dt = datetime.strptime(date_str, '%Y-%m-%d')
        return dt.strftime('%d-%b-%Y')
    except ValueError:
        return date_str

@app.route('/api/get-entries', methods=['GET'])
def get_entries():
    filter_type = request.args.get('filter', 'daily')
    start_date_param = request.args.get('startDate')
    end_date_param = request.args.get('endDate')
    
    now = datetime.now()
    current_year = now.strftime('%Y')
    current_month = now.strftime('%B')
    current_date = now.strftime('%Y-%m-%d')

    raw_entries = []

    if not os.path.exists(ACCOUNTS_ROOT):
        return jsonify({"entries": [], "grandTotal": 0, "filterType": filter_type}), 200

    for root, dirs, files in os.walk(ACCOUNTS_ROOT):
        for file in files:
            if file.endswith('.xlsx'):
                file_path = os.path.join(root, file)
                file_date_str = file.replace('.xlsx', '')
                
                try:
                    file_dt = datetime.strptime(file_date_str, '%Y-%m-%d')
                    f_year = file_dt.strftime('%Y')
                    f_month = file_dt.strftime('%B')
                except ValueError:
                    continue

                # Apply Filters
                if filter_type == 'daily':
                    if file_date_str != current_date:
                        continue
                elif filter_type == 'custom':
                    if start_date_param and file_date_str < start_date_param:
                        continue
                    if end_date_param and file_date_str > end_date_param:
                        continue
                elif filter_type == 'monthly':
                    if f_year != current_year or f_month != current_month:
                        continue
                elif filter_type == 'yearly':
                    if f_year != current_year:
                        continue

                try:
                    wb = openpyxl.load_workbook(file_path, data_only=True)
                    ws = wb.active
                    for row in ws.iter_rows(min_row=2, values_only=True):
                        if row and len(row) >= 3:
                            raw_entries.append({
                                "date": format_nice_date(file_date_str), # Formatted date
                                "month": f_month,
                                "year": f_year,
                                "time": str(row[0]),
                                "scenario": str(row[1]),
                                "amount": float(row[2]),
                                "description": str(row[3]) if len(row) > 3 else ""
                            })
                except Exception:
                    continue

    grand_total = sum(e['amount'] for e in raw_entries)
    processed_entries = []

    if filter_type == 'monthly':
        date_map = {}
        for e in raw_entries:
            d = e['date']
            date_map[d] = date_map.get(d, 0) + e['amount']
        for d, total in sorted(date_map.items()):
            processed_entries.append({
                "groupKey": d,
                "amount": total,
                "description": "Total transactions for {}".format(d)
            })
    elif filter_type == 'yearly':
        month_map = {}
        for e in raw_entries:
            m = e['month']
            month_map[m] = month_map.get(m, 0) + e['amount']
        for m, total in month_map.items():
            processed_entries.append({
                "groupKey": m,
                "amount": total,
                "description": "Total transactions for {} {}".format(m, current_year)
            })
    else:
        # Daily, Custom, or All Time: sort descending
        raw_entries.sort(key=lambda x: x['date'], reverse=True)
        processed_entries = raw_entries

    return jsonify({
        "entries": processed_entries,
        "grandTotal": grand_total,
        "filterType": filter_type
    }), 200

if __name__ == '__main__':
    app.run(debug=True, port=5000)