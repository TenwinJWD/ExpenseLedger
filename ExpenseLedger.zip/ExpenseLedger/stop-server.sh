#!/bin/bash

echo "=================================================="
echo "   Stopping All Financial Ledger Servers & Ports   "
echo "=================================================="

# 1. Find and kill all python3 app.py processes
PIDS=$(pgrep -f "python3 app.py")
if [ -n "$PIDS" ]; then
    echo "Stopping Python Flask processes (PID: $PIDS)..."
    kill -9 $PIDS 2>/dev/null
fi

# 2. Dynamically find and free up ANY port currently occupied by Python processes
PYTHON_PIDS=$(pgrep -f "python")
for PID in $PYTHON_PIDS; do
    PORTS=$(lsof -Pi -p $PID -t -sTCP:LISTEN 2>/dev/null)
    if [ -n "$PORTS" ]; then
        for PORT in $PORTS; do
            echo "Freeing up port $PORT occupied by Python PID $PID..."
            kill -9 $PORT 2>/dev/null
        done
    fi
done

# 3. Fallback: scan common local development ports (5000 to 5010)
for PORT in $(seq 5000 5010); do
    PORT_PID=$(lsof -ti :$PORT 2>/dev/null)
    if [ -n "$PORT_PID" ]; then
        echo "Clearing port $PORT (PID $PORT_PID)..."
        kill -9 $PORT_PID 2>/dev/null
    fi
done

echo "=================================================="
echo " All servers and associated ports have been cleared!"
echo "=================================================="