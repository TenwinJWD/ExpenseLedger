@echo off
TITLE Financial Ledger Runner
echo ==================================================
echo    Starting Financial Ledger Setup (Windows)       
echo ==================================================

:: 1. Navigate to backend and install dependencies
cd backend
echo [1/3] Installing Python dependencies...
pip install -r requirements.txt

:: 2. Start Flask Backend in a new command prompt window
echo [2/3] Starting Python Flask API server...
start cmd /k "python app.py"

:: Return to root directory
cd ..

:: Wait 3 seconds for the server to spin up
timeout /t 3 /nobreak > nul

:: 3. Open Frontend HTML in default browser
echo [3/3] Opening Frontend in default browser...
start frontend\index.html

echo ==================================================
echo  Setup complete! Backend is running in a separate window.
echo ==================================================
pause