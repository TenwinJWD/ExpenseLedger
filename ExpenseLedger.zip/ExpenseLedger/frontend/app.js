var app = angular.module('ledgerApp', []);

app.controller('LedgerController', ['$scope', '$http', function($scope, $http) {
    $scope.activeTab = 'form';
    $scope.currentFilter = 'daily'; // Default to daily
    
    function getTodayString() {
        const d = new Date();
        let month = '' + (d.getMonth() + 1);
        let day = '' + d.getDate();
        let year = d.getFullYear();
        if (month.length < 2) month = '0' + month;
        if (day.length < 2) day = '0' + day;
        return [year, month, day].join('-');
    }

    $scope.formData = {
        date: getTodayString(),
        scenario: '',
        amount: '',
        description: ''
    };

    $scope.dateRange = {
        start: getTodayString().substring(0, 8) + '01',
        end: getTodayString()
    };

    $scope.entries = [];
    $scope.grandTotal = 0.00;
    
    $scope.successMessage = '';
    $scope.errorMessage = '';

    // Auto-load daily data on startup
    $scope.init = function() {
        $scope.loadLedgerData();
    };

    $scope.switchTab = function(tabName) {
        $scope.activeTab = tabName;
        $scope.successMessage = '';
        $scope.errorMessage = '';
        if (tabName === 'ledger') {
            $scope.loadLedgerData();
        }
    };

    $scope.clearForm = function() {
        $scope.formData = {
            date: getTodayString(),
            scenario: '',
            amount: '',
            description: ''
        };
        $scope.successMessage = '';
        $scope.errorMessage = '';
    };

    $scope.submitEntry = function() {
        if (!$scope.formData.scenario || !$scope.formData.amount || !$scope.formData.date) {
            $scope.errorMessage = "Please fill out all required fields.";
            return;
        }

        $http.post('http://localhost:5000/api/save-entry', $scope.formData)
            .then(function(response) {
                $scope.successMessage = response.data.message;
                $scope.errorMessage = '';
                $scope.formData.scenario = '';
                $scope.formData.amount = '';
                $scope.formData.description = '';
            }, function(error) {
                $scope.errorMessage = error.data.message || "Failed to communicate with Python backend API.";
                $scope.successMessage = '';
            });
    };

    $scope.setFilter = function(filterType) {
        $scope.currentFilter = filterType;
        if (filterType !== 'custom') {
            // Auto-load for daily, monthly, yearly, all time
            $scope.loadLedgerData();
        }
    };

    $scope.loadLedgerData = function() {
        let url = 'http://localhost:5000/api/get-entries?filter=' + $scope.currentFilter;
        
        if ($scope.currentFilter === 'custom') {
            if ($scope.dateRange.start) url += '&startDate=' + $scope.dateRange.start;
            if ($scope.dateRange.end) url += '&endDate=' + $scope.dateRange.end;
        }

        $http.get(url)
            .then(function(response) {
                $scope.entries = response.data.entries;
                $scope.grandTotal = response.data.grandTotal;
            }, function(error) {
                console.error("Error loading ledger entries:", error);
            });
    };

    // Run initialization
    $scope.init();
}]);