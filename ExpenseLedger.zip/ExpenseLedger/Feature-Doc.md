# Feature Documentation: Financial Ledger & Expense Tracker

## 1. Project Overview
The **Financial Ledger & Expense Tracker** is a full-stack local application designed to capture, organize, and summarize financial transactions and amounts across different business or personal scenarios. It bridges a modern **AngularJS frontend SPA** with an automated **Python Flask backend** that writes directly to hierarchical Excel workbooks stored on the local desktop.

---

## 2. Architecture & Tech Stack
* **Frontend:** HTML5, CSS3 (Modern Flexbox/Grid UI), AngularJS (v1.8.2 SPA framework)
* **Controller Script:** Separate modular JavaScript controller (`app.js`) handling REST communication and UI state.
* **Backend:** Python Flask API, `openpyxl` library for spreadsheet manipulation.
* **Storage:** Local Excel files (`.xlsx`) organized systematically in Desktop directory structure.

---

## 3. Directory & File Structure Flow
When the user submits entries through the form, the backend creates directories and appends data following this exact structure:

```text
C:/<user>/Desktop/Accounts/
└── <Current Year> (e.g., 2026)
    └── <Current Month> (e.g., October)
        └── <YYYY-MM-DD>.xlsx (e.g., 2026-10-15.xlsx)